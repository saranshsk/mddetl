#The program starts here. This module would call the underlying fetch_data_modules.
import mddetl
from mddetl import df_fnc_calling_module
print ("The fuctionality is being executed for file id:")
df_fnc_calling_module.call_fnc ( u'1' )
print ("The program has ended. Refer log file for more information")
