import cx_Oracle
import pprint

def get_metadata_fnc (dff_info_id):
    repo_db_conn = cx_Oracle.connect ( 'metadata/METADATA@orcl' )
    db_cursor = repo_db_conn.cursor()
#Variable assignment
    columns_query_1=[]
    row_values_query_1=[]
    columns_query_2=[]
    row_values_query_2=[]
#SQL query below to fetch from df_inp table
    db_sql_query_1 = u"select \
        DF_INP_PK,\
        DF_TYPE,\
        DF_NAME,\
        DF_SYSTEM,\
        DF_INFO,\
        CONNECTION_INFO,\
        FILE_DELIM,\
        FIELD_QUOTE,\
        SKIP_BLANK_LINES,\
        TRIM_SPACES,\
        REPLACE_BLANKS_BY,\
        LINES_TO_LOAD,\
        encoding,\
        CONTAINS_HEADER,\
        CONTAINS_TRAILER,\
        LINES_TO_SKIP,\
        POLL_INTERVAL_MINUTES,\
        POLL_COUNT_NUMBER\
    from\
        DF_INP where \
        CURRENT_IND = 'Y'\
        AND DF_INP_PK  = :input_dff_info_id"
    db_cursor.execute ( db_sql_query_1, input_dff_info_id = dff_info_id )
    sql_query_1_rs = []
    for rs in db_cursor:
        d = {}
        d['DF_INP_PK'] = rs[0]
        d['DF_TYPE'] = rs[1]
        d['DF_NAME'] = rs[2]
        d['DF_SYSTEM'] = rs[3]
        d['DF_INFO'] = rs[4]
        d['CONNECTION_INFO'] = rs[5]
        d['FILE_DELIM'] = rs[6]
        d['FIELD_QUOTE'] = rs[7]
        d['SKIP_BLANK_LINES'] = rs[8]
        d['TRIM_SPACES'] = rs[9]
        d['REPLACE_BLANKS_BY'] = rs[10]
        d['LINES_TO_LOAD'] = rs[11]
        d['encoding'] = rs[12]
        d['CONTAINS_HEADER'] = rs[13]
        d['CONTAINS_TRAILER'] = rs[14]
        d['LINES_TO_SKIP'] = rs[15]
        d['POLL_INTERVAL_MINUTES'] = rs[16]
        d['POLL_COUNT_NUMBER'] = rs[17]
        sql_query_1_rs.append ( d )
    #row_values_query_1 = db_cursor.fetchall()
    for i in range(0, len(db_cursor.description)):
        columns_query_1.append(db_cursor.description[i][0])
    pp = pprint.PrettyPrinter(width=1024)
    pp.pprint(columns_query_1)
    pp.pprint(row_values_query_1)
#SQL query below to fetch from df_inp_validation and df_validation tables
    db_sql_query_2 = "SELECT\
    VALIDATION_NAME,\
    VALIDATION_CMD,\
    DF_VALIDATION_PARAMETER,\
    DF_VALIDATION_CHECK,\
    FILE_DELIM,\
    FIELD_QUOTE,\
    SKIP_BLANK_LINES,\
    TRIM_SPACES,\
    REPLACE_BLANKS_BY,\
    LINES_TO_LOAD,\
    ENCODING,\
    CONTAINS_HEADER,\
    CONTAINS_TRAILER,\
    LINES_TO_SKIP \
    FROM \
    DF_INP_VALIDATION A,\
    DF_VALIDATION B,\
    DF_INP C\
    WHERE\
        A.DF_VALIDATION_FK = B.DF_VALIDATION_PK\
    AND\
        A.DF_INP_FK = C.DF_INP_PK\
    AND\
        A.CURRENT_IND = 'Y'\
    AND\
        B.CURRENT_IND = 'Y'\
    AND\
        C.CURRENT_IND = 'Y'\
    AND A.DF_INP_FK = :input_dff_info_id"
    db_cursor.execute ( db_sql_query_2, input_dff_info_id = dff_info_id )
    sql_query_2_rs = []
    for rs in db_cursor:
        d = {}
        d['VALIDATION_NAME'] = rs[0]
        d['VALIDATION_CMD'] = rs[1]
        d['DF_VALIDATION_PARAMETER'] = rs[2]
        d['DF_VALIDATION_CHECK'] = rs[3]
        d['FILE_DELIM'] = rs[4]
        d['FIELD_QUOTE'] = rs[5]
        d['SKIP_BLANK_LINES'] = rs[6]
        d['TRIM_SPACES'] = rs[7]
        d['REPLACE_BLANKS_BY'] = rs[8]
        d['LINES_TO_LOAD'] = rs[9]
        d['ENCODING'] = rs[10]
        d['CONTAINS_HEADER'] = rs[11]
        d['CONTAINS_TRAILER'] = rs[12]
        d['LINES_TO_SKIP'] = rs[13]
        sql_query_2_rs.append ( d )
    #row_values_query_2 = db_cursor.fetchall()
    for i in range(0, len(db_cursor.description)):
        columns_query_2.append(db_cursor.description[i][0])
    pp = pprint.PrettyPrinter(width=1024)
    pp.pprint(columns_query_2)
    pp.pprint(row_values_query_2)
    print ('Function get_dff_info_data completed successfully')
    db_cursor.close()
    return (sql_query_1_rs, sql_query_2_rs)
