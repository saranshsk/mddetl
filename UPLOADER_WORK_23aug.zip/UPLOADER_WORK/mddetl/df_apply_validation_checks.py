#This module applies validation checks on the sourced file
import os
from subprocess import Popen, PIPE

def validation_fnc (dff_path, dff_validation_rs):
    for rs_dict in dff_validation_rs:
        apply_validation_fnc ( dff_path, rs_dict['VALIDATION_NAME'], rs_dict['DF_VALIDATION_PARAMETER'], rs_dict['VALIDATION_CMD'], rs_dict['DF_VALIDATION_CHECK'], rs_dict['FILE_DELIM'])
def apply_validation_fnc (dff_path, DFF_VALIDATION_TYPE, DFF_VALIDATION_PARAMETER, VALIDATION_CODE_PARAM, DFF_VALIDATION_CHECK, DFF_FILE_DELIM):
    validation_cmd = VALIDATION_CODE_PARAM
    os_file_path, os_file_name = os.path.split(dff_path)
    #String replacement in the command before firing them on the system
    validation_cmd = validation_cmd.replace('<INP>', dff_path)
    validation_cmd = validation_cmd.replace('<PARAM>', DFF_VALIDATION_PARAMETER)
    validation_cmd = validation_cmd.replace('<INP_DELIM>', DFF_FILE_DELIM)
    validation_cmd = validation_cmd.replace('<FILEPATH>', os_file_path)
    validation_cmd = validation_cmd.replace('<FILENAME>', os_file_name)
    print("Executing the command pre-configured for : ", DFF_VALIDATION_TYPE, validation_cmd)
    #Command for validation fired below this point
    p = Popen ( validation_cmd, shell = True, stdout = PIPE, stderr = PIPE )
    validation_cmd_result, err = p.communicate()
    print("Execution return code: ", p.returncode)
    print(validation_cmd_result.rstrip(), err.rstrip())
    if p.returncode == 0 and DFF_VALIDATION_CHECK <> "PROCESS":
        print("Command executed for : ", DFF_VALIDATION_TYPE)
        print("Applying check", DFF_VALIDATION_PARAMETER)
        if eval ( validation_cmd_result.rstrip() + ' ' + DFF_VALIDATION_PARAMETER ):
            print((validation_cmd_result.rstrip()))
            print("Validation successful")
        else:
            print("Validation failed")
    if p.returncode == 0 and DFF_VALIDATION_CHECK == "PROCESS":
        print("Command executed for : ", DFF_VALIDATION_TYPE)
        print("Applying file processing task: ", DFF_VALIDATION_PARAMETER)
        print("File processing done successfully")
