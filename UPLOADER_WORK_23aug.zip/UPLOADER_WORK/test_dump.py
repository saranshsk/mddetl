#This module extracts the data from staging tables to store it into local lists/dictionaries/tuples. Latter the data is inserted into the core/dimension tables
import cx_Oracle
import csv
import sys

repo_db_conn = cx_Oracle.connect ( 'metadata/METADATA@orcl' )
db_cursor=repo_db_conn.cursor()
db_cursor1=repo_db_conn.cursor()

db_sql_query_1 = u"select SQL_VALID_ROWS from DF_INP_TO_OUT_MAP"

res = db_cursor.execute(db_sql_query_1)
row1 = res.fetchall()

for i in row1:
	print (i[0])
	var1 = str(i[0])
	print(var1)
	res1 = db_cursor1.execute(var1)
	row2 = res1.fetchall()
	for j in row2:
		print j[0]+' , '+j[1]
db_cursor.close()