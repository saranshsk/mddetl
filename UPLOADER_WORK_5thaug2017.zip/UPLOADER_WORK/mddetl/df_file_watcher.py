#This module watches for any new file in the source directory
import glob
import time

def filewatcher (sql_query_1_rs, rs_index):
	rs_dict = sql_query_1_rs[rs_index]
	dff=[]
	for iteration_count in range(0, rs_dict['POLL_COUNT_NUMBER']):
		print ("Iteration %d: looking for %s/%s") % (iteration_count, rs_dict['CONNECTION_INFO'], rs_dict['DF_NAME'])
		dff = glob.glob (rs_dict['CONNECTION_INFO'] + '/' + rs_dict['DF_NAME'])
		if dff:
			print ("found file: ", dff)
			break
		else:
			print ("file not found, sleeping for %d seconds" % rs_dict['POLL_INTERVAL_MINUTES'])
		time.sleep (rs_dict['POLL_INTERVAL_MINUTES'])
	return dff

