#This module fetches data from metadata tables for the specific file
import df_get_matadata_info
import df_file_watcher
import df_apply_validation_checks
import df_dump_data_into_target

def call_fnc (DF_INP_PK):
    sql_query_1_rs, sql_query_2_rs  = df_get_matadata_info.get_metadata_fnc (DF_INP_PK)
    print ("The programs is fetching metadata information from multiple tables and storing them into resultsets")
    for rs_1 in sql_query_1_rs:
        print (rs_1)
    for rs_2 in sql_query_2_rs:
        print (rs_2)
    #Function being called to search for any new file received under the source directory
    file_name = df_file_watcher.filewatcher (sql_query_1_rs, 0)
    #Function being called to apply validations on the file received
    df_apply_validation_checks.validation_fnc (file_name[0], sql_query_2_rs)
    #Function being called to dump data from the file received into the corresponding staging tables
    df_dump_data_into_target.insert_data_fnc(file_name[0], sql_query_2_rs)
